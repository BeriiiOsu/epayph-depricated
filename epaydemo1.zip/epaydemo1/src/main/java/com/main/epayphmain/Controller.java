package com.main.epayphmain;


import com.twilio.rest.chat.v1.service.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;
import java.util.Random;


public class Controller {

    private Stage signupStage;
    private Scene signupScene;
    @FXML
    private Button signupBtn;
    @FXML
    private Button signupBackBtn;
    @FXML
    private Button showBtn;
    @FXML
    private TextField textFieldPass;
    @FXML
    private CheckBox checkBox;
    @FXML
    private Button dashBtn;



    @FXML
    void changeVisibility(ActionEvent e){
        UserSession userSession = UserSession.getInstance();
        userSession.setPassTEXT(passTxt.getText());
        if(checkBox.isSelected()){
            if(passTxt.getText().isBlank()){
                userSession.setPassTEXT(textFieldPass.getText());
            }
            textFieldPass.setText(userSession.getPassTEXT());
            textFieldPass.setVisible(true);
            passTxt.setVisible(false);
            return;
        }
        passTxt.setText(userSession.getPassTEXT());
        passTxt.setVisible(true);
        textFieldPass.setVisible(false);
    }


    public void setSignupBackBtn(ActionEvent e) throws IOException {
        FXMLLoader loader = new FXMLLoader(Main.class.getResource("loginScreen.fxml"));
        signupStage  = (Stage)((Node)e.getSource()).getScene().getWindow();
        signupScene = new Scene(loader.load());
        signupStage.setScene(signupScene);
        signupStage.show();
    }
    public void signupWindow(ActionEvent e) throws IOException {
        FXMLLoader loader = new FXMLLoader(Main.class.getResource("signupScreen.fxml"));
        signupStage  = (Stage)((Node)e.getSource()).getScene().getWindow();
        signupScene = new Scene(loader.load());
        signupStage.setScene(signupScene);
        signupStage.show();
    }
    LocalDate mainDate = LocalDate.now();
    String strCurrentDate = String.valueOf(mainDate);
    //userdataleak
    private static String userFname = "";
    private static String userCNo = "";
    private static String userEA = "";
    private static String bDAY = "";
    private static String gnder = "";
    private static String userPN = "";
    double userBal = 0.0;
    private static String userLU = "";
    private static String userCT = "";
    private static String userCN = "";
    private static String userVT = "";
    private static String userCVC = "";
    private static String userSavingsNo = "";

    @FXML
    private TextField emailTxt;
    @FXML
    private TextField passTxt;
    @FXML
    private Label loginMessage;
    @FXML
    private Label currentDate;
    @FXML
    private Label nameID;
    @FXML
    private Label fullnameID;
    @FXML
    private Label balanceID;
    @FXML
    private Label lastupdatedID;
    @FXML
    private Circle mcColor1;
    @FXML
    private Circle mcColor2;
    @FXML
    private ImageView visaimg;
    //login section


    public void validateLogin(ActionEvent event){
        UserSession us9 = UserSession.getInstance();
//        us9.setPassTEXT(passTxt.getText());


        if(!emailTxt.getText().isBlank() && !passTxt.getText().isBlank() || !textFieldPass.getText().isBlank()){
        Database connectNow = new Database();
        Connection db = connectNow.getLink();
        String isAccountFound = "select count(1) from epaytable where emailaddress = '" + emailTxt.getText() + "' OR phonenumber = '" + emailTxt.getText() + "'";
        String verify = "select count(1) from epaytable where (emailaddress = '" + emailTxt.getText() + "' OR phonenumber = '" + emailTxt.getText() + "') AND password = '" + passTxt.getText() + "' OR password = '" + textFieldPass.getText() + "'";
        try{
            Statement statement = db.createStatement();
            ResultSet queryResult = statement.executeQuery(isAccountFound);

            while(queryResult.next()){
                if(queryResult.getInt(1) == 1){
                    UserSession us1 = UserSession.getInstance();
                    us1.setUserEmail(emailTxt.getText());
                    us1.setCurrentEmail(emailTxt.getText());

                    Database db20 = new Database();
                    Connection connectDB20 = db20.getLink();
                    String OTP = "select OTP from epaytable where emailaddress = ?";
                    PreparedStatement pst = connectDB20.prepareStatement(OTP);
                    pst.setString(1, us1.getUserEmail());
                    ResultSet rs2 = pst.executeQuery();

                    if(rs2.next()){
                        String isOTP = rs2.getString("OTP");
                        if(isOTP.equals("ON")){
                            Random random = new Random();
                            int otp = random.nextInt(1000000);
                            String theCodeOTP = String.format("%06d", otp);
                            emailSender es = new emailSender();
                            es.sendEmail("OTP Code | Epay.PH",  "Your OTP Code: " + theCodeOTP, us1.getCurrentEmail());
                            dialogBox dB = new dialogBox();
                            boolean isConfirm = dB.getAlertOTPBox(theCodeOTP);
                            if(!isConfirm){
                                return;
                            }
                        }

                    }


                    //nested while loop
                    Statement statement1 = db.createStatement();
                    ResultSet verifyResult = statement1.executeQuery(verify);
                        while(verifyResult.next()){
                            if(verifyResult.getInt(1) == 1){
                                loginMessage.setText("Login Success!");
//                                Database db3 = new Database();
//                                Connection connectDB3 = db3.getLink();
//
//                                Statement stmtStatus = connectDB3.createStatement();
//                                String promptStatus = "select status from epaytable where emailaddress = '" + emailTxt.getText() + "' ";
//
//                                ResultSet statusResult = stmtStatus.executeQuery(promptStatus);
//
//                                while(statusResult.next()){
//                                    String resultSts = statusResult.getString("status");
//                                    if(resultSts.equals("BLOCKED")) {
//                                        loginMessage.setText("Your Account is BLOCKED!");
//                                        return;
//                                    }
//                                }

                                FXMLLoader loginLoader = new FXMLLoader(Main.class.getResource("mainScreen.fxml"));
                                Stage loginStage  = (Stage)((Node)event.getSource()).getScene().getWindow();
                                Scene loginScene = new Scene(loginLoader.load());

                                //current date
                                Controller mainController = loginLoader.getController();
                                mainController.currentDate.setText("Today, " + strCurrentDate);

                                //userdata
                                Database db2 = new Database();
                                Connection connectDB2 = db2.getLink();

                                Statement userdataStmt = connectDB2.createStatement();
                                String userdataCMD = "select fullname,cardnumber,emailaddress,birthday,gender,phonenumber,balance,lastupdated,cardType,cardNetwork,validthru,cvc,savingsnumber from epaytable where emailaddress = '" + emailTxt.getText()+ "' ";
                                ResultSet userDataResult = userdataStmt.executeQuery(userdataCMD);


                                while(userDataResult.next()){
                                    userFname = userDataResult.getString("fullname");
                                    userCNo = userDataResult.getString("cardnumber");
                                    userEA = userDataResult.getString("emailaddress");
                                    bDAY = userDataResult.getString("birthday");
                                    gnder = userDataResult.getString("gender");
                                    userPN = userDataResult.getString("phonenumber");
                                    userBal = userDataResult.getDouble("balance");
                                    userLU = userDataResult.getString("lastupdated");
                                    userCT = userDataResult.getString("cardType");
                                    userCN = userDataResult.getString("cardNetwork");
                                    userVT = userDataResult.getString("validthru");
                                    userCVC = userDataResult.getString("cvc");
                                    userSavingsNo = userDataResult.getString("savingsnumber");

                                }
                                us1.setCardnumber(userCNo);
                                us1.setUserCardNumber(userCNo);
                                us1.setCurrentFullname(userFname);
                                us1.setCurrentEmail(userEA);
                                us1.setSavingsnumber(userSavingsNo);




                                Controller mainController2 = loginLoader.getController();
                                int spaceIndex = userFname.indexOf(" ");
                                if(spaceIndex == -1){
                                    mainController2.nameID.setText(userFname);
                                }else{
                                    mainController2.nameID.setText(userFname.substring(0, spaceIndex));
                                }
                                Image im = new Image("file:C:\\Java Project\\epaydemo1\\src\\visalogo.png");
                                mainController2.fullnameID.setText(userFname);
                                mainController2.balanceID.setText(String.valueOf(userBal));
                                mainController2.lastupdatedID.setText(userLU);
                                if(userCN == null){
                                    mainController2.mcColor1.setStyle("-fx-fill: #1239b5;");
                                    mainController2.mcColor2.setStyle("-fx-fill: #1239b5;");
                                    mainController2.visaimg.setVisible(false);
                                } else if (userCN.equals("Mastercard")) {
                                    mainController2.mcColor1.setStyle("-fx-fill: #ec0014;");
                                    mainController2.mcColor2.setStyle("-fx-fill: #f79f14;");
                                    mainController2.visaimg.setVisible(true);
                                } else if (userCN.equals("Visa")) {
                                    mainController2.mcColor1.setStyle("-fx-fill: #1239b5;");
                                    mainController2.mcColor2.setStyle("-fx-fill: #1239b5;");
                                    mainController2.visaimg.setVisible(false);
                                    mainController2.visaimg.setImage(im);
                                } else{
                                    mainController2.mcColor1.setStyle("-fx-fill: #1239b5;");
                                    mainController2.mcColor2.setStyle("-fx-fill: #1239b5;");
                                    mainController2.visaimg.setVisible(false);
                                }

                                loginStage.setScene(loginScene);
                                loginStage.show();

                            }else{
                                loginMessage.setText("Invalid Email/Phone number or Password!");
                                break;
                            }
                        }
                }else{
                    loginMessage.setText("Account not found!");
                    break;
                }
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        }else{
            loginMessage.setText("Type something in email or password!");
        }
    }

    public void dashboardBtn(ActionEvent event) throws IOException, SQLException {
        FXMLLoader loginLoader = new FXMLLoader(Main.class.getResource("mainScreen.fxml"));
        Stage loginStage  = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene loginScene = new Scene(loginLoader.load());

        //current date
        Controller mainController = loginLoader.getController();
        mainController.currentDate.setText("Today, " + strCurrentDate);

        //userdata
        Database db2 = new Database();
        Connection connectDB2 = db2.getLink();

        Statement userdataStmt = connectDB2.createStatement();
        String userdataCMD = "select fullname,cardnumber,emailaddress,birthday,gender,phonenumber,balance,lastupdated,cardType,cardNetwork,validthru,cvc from epaytable where emailaddress = '" + userEA + "' ";
        ResultSet userDataResult = userdataStmt.executeQuery(userdataCMD);

        while(userDataResult.next()){
            userFname = userDataResult.getString("fullname");
            userCNo = userDataResult.getString("cardnumber");
            userEA = userDataResult.getString("emailaddress");
            bDAY = userDataResult.getString("birthday");
            gnder = userDataResult.getString("gender");
            userPN = userDataResult.getString("phonenumber");
            userBal = userDataResult.getDouble("balance");
            userLU = userDataResult.getString("lastupdated");
            userCT = userDataResult.getString("cardType");
            userCN = userDataResult.getString("cardNetwork");
            userVT = userDataResult.getString("validthru");
            userCVC = userDataResult.getString("cvc");

        }

        UserSession us1 = UserSession.getInstance();

        us1.setUserEmail(us1.getUserEmail());
        Controller mainController2 = loginLoader.getController();
        int spaceIndex = userFname.indexOf(" ");
        if(spaceIndex == -1){
            mainController2.nameID.setText(userFname);
        }else{
            mainController2.nameID.setText(userFname.substring(0, spaceIndex));
        }
        Image im = new Image("file:C:\\Java Project\\epaydemo1\\src\\visalogo.png");
        mainController2.fullnameID.setText(userFname);
        mainController2.balanceID.setText(String.valueOf(userBal));
        mainController2.lastupdatedID.setText(userLU);
        if(userCN == null){
            mainController2.mcColor1.setStyle("-fx-fill: #1239b5;");
            mainController2.mcColor2.setStyle("-fx-fill: #1239b5;");
            mainController2.visaimg.setVisible(false);
        } else if (userCN.equals("Mastercard")) {
            mainController2.mcColor1.setStyle("-fx-fill: #ec0014;");
            mainController2.mcColor2.setStyle("-fx-fill: #f79f14;");
            mainController2.visaimg.setVisible(true);
        } else if (userCN.equals("Visa")) {
            mainController2.mcColor1.setStyle("-fx-fill: #1239b5;");
            mainController2.mcColor2.setStyle("-fx-fill: #1239b5;");
            mainController2.visaimg.setVisible(false);
            mainController2.visaimg.setImage(im);
        } else{
            mainController2.mcColor1.setStyle("-fx-fill: #1239b5;");
            mainController2.mcColor2.setStyle("-fx-fill: #1239b5;");
            mainController2.visaimg.setVisible(false);
        }
        loginStage.setScene(loginScene);
        loginStage.show();
    }



    LocalDateTime mainDate2 = LocalDateTime.now();
    private String payeeEmail = "";
    @FXML
    private TextField payee;
    @FXML
    private TextField amountToPay;
    @FXML
    private TextField messageToPayee;
    @FXML
    private Button smBtn;
    public void sendMoneyBtn(ActionEvent e) throws SQLException {
        String isTrue = "";
        if(payee.getText().isBlank() && amountToPay.getText().isBlank() && messageToPayee.getText().isBlank()){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Blank Text Fields");
            alert.setContentText("Input something!");
            alert.showAndWait();
            return;
        }
        Database db5 = new Database();
        Connection connectDB5 = db5.getLink();
        String ul = "select status from epaytable where emailaddress = ?";
        PreparedStatement pst = connectDB5.prepareStatement(ul);
        pst.setString(1, userEA);
        ResultSet rs2 = pst.executeQuery();

        if(rs2.next()){
            isTrue = rs2.getString("status");
        }
        if(isTrue == null){
            Alert at = new Alert(Alert.AlertType.ERROR);
            at.setTitle("Error");
            at.setHeaderText("Status = null");
            at.setContentText("Please verify your account!");
            at.showAndWait();
            return;
        } else if (isTrue.equals("")) {
            Alert at = new Alert(Alert.AlertType.ERROR);
            at.setTitle("Error");
            at.setHeaderText("Status = null");
            at.setContentText("Please verify your account!");
            at.showAndWait();
            return;
        }else if (isTrue.equals("Non-Verify")) {
            Alert at = new Alert(Alert.AlertType.ERROR);
            at.setTitle("Error");
            at.setHeaderText("Status = Non-Verify");
            at.setContentText("Please verify your account!");
            at.showAndWait();
            return;
        }

        String strPay = "You are about to pay "+ amountToPay.getText() +" to "+ payee.getText() + " account.";
        Alert al = new Alert(Alert.AlertType.CONFIRMATION);
        al.setTitle("Confirmation");
        al.setHeaderText(strPay);
        al.setContentText("Do you wish to proceed?");

        ButtonType confirmButton = new ButtonType("Confirm");
        ButtonType cancelButton = new ButtonType("Cancel");

        al.getButtonTypes().setAll(confirmButton, cancelButton);

        al.showAndWait().ifPresent(response -> {
            if (response == confirmButton) {
    try {
        UserSession us = UserSession.getInstance();

        Database db6 = new Database();
        Connection connectDB6 = db6.getLink();
        String urs = "select status from epaytable where emailaddress = ?";
        PreparedStatement pts = connectDB6.prepareStatement(urs);
        pts.setString(1, us.getVerifyStatus());

        ResultSet ts = pts.executeQuery();
        while (ts.next()) {
            String getRs = ts.getString("status");
            if (getRs.equals("Non-Verify")) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText("Not Available.");
                alert.setContentText("Please verify your account first! \nGoto Profile tab and verify!");
                alert.showAndWait();
                return;
            } else if (getRs.equals("BLOCKED")) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText("Not Available.");
                alert.setContentText("Account BLOCKED! Please Contact Your Administrator.");
                alert.showAndWait();
                return;
            }
        }

        Database db4 = new Database();
        Connection connectDB4 = db4.getLink();
        connectDB4.setAutoCommit(false);

        try {
            Statement getData = connectDB4.createStatement();
            Statement usergetData = connectDB4.createStatement();
            Statement findData = connectDB4.createStatement();

            String payeeName = "";
            double payeeBal = 0.0;
            double userBalance = 0.0;
            String findPayee = "select count(1) from epaytable where cardnumber = '" + payee.getText() + "' ";
            String strgetDataPayee = "select balance, fullname, emailaddress from epaytable where cardnumber = '" + payee.getText() + "'";
            String strgetDataUser = "select balance from epaytable where emailaddress = '" + userEA + "'";


            ResultSet rsFindPayee = findData.executeQuery(findPayee);

            if (rsFindPayee.next() && rsFindPayee.getInt(1) == 1) {

                ResultSet rsGetData = getData.executeQuery(strgetDataPayee);
                while (rsGetData.next()) {
                    payeeBal = rsGetData.getDouble("balance");
                    payeeName = rsGetData.getString("fullname");
                    payeeEmail = rsGetData.getString("emailaddress");
                }


                ResultSet rsGetDataUser = usergetData.executeQuery(strgetDataUser);
                while (rsGetDataUser.next()) {
                    userBalance = rsGetDataUser.getDouble("balance");
                }

                double dAmoutpay = Double.parseDouble(amountToPay.getText());
                if (dAmoutpay <= 0) {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error");
                    alert.setHeaderText("Invalid!");
                    alert.setContentText("Amount should not be less than or equal to 0!");
                    alert.showAndWait();
                    return;
                } else if (dAmoutpay > userBalance) {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error");
                    alert.setHeaderText("Invalid!");
                    alert.setContentText("Insufficient Balance!");
                    alert.showAndWait();
                    return;

                }
                //generates transac ID
                Random random = new Random();
                int id1 = random.nextInt(1000000);
                int id2 = random.nextInt(1000000);
                String transID1 = String.format("%06d", id1);
                String transID2 = String.format("%06d", id2);

                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
                String formattedDateTime = mainDate2.format(formatter);

                // Update balances
                String updateUserBal = "UPDATE epaytable SET balance = ?, lastupdated = ? WHERE emailaddress = ?";

                String strvalueUP = String.format("%.2f", userBalance - dAmoutpay);
                double dobDeci = Double.parseDouble(strvalueUP);


                PreparedStatement updateUserBalStmt = connectDB4.prepareStatement(updateUserBal);
                updateUserBalStmt.setDouble(1, dobDeci);
                updateUserBalStmt.setString(2, formattedDateTime);
                updateUserBalStmt.setString(3, userEA);
                updateUserBalStmt.executeUpdate();


                String updatePayeeBal = "UPDATE epaytable SET balance = ?, lastupdated = ? WHERE cardnumber = ?";

                String strvalueUP2 = String.format("%.2f", payeeBal + dAmoutpay);
                double dobDeci2 = Double.parseDouble(strvalueUP2);


                PreparedStatement updatePayeeBalStmt = connectDB4.prepareStatement(updatePayeeBal);
                updatePayeeBalStmt.setDouble(1, dobDeci2);
                updatePayeeBalStmt.setString(2, formattedDateTime);
                updatePayeeBalStmt.setString(3, payee.getText());
                updatePayeeBalStmt.executeUpdate();
                connectDB4.commit();




                    us.setTransactioID(transID2);

                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Notice");
                alert.setHeaderText("Success!");
                alert.setContentText("PHP " + dAmoutpay + " has been sent to " + payeeName + "!\n Transaction ID: " + transID1);

                sendMessageEmail(messageToPayee.getText(), String.valueOf(dAmoutpay));

                //the user who sent
                Database db01 = new Database();
                Connection connectDB01 = db01.getLink();
                String usl = "INSERT INTO transactiontable (accountnumber, sendorrecieve, id) VALUES (?, ?, ?)";
                PreparedStatement prs = connectDB01.prepareStatement(usl);
                prs.setString(1, us.getUserCardNumber());
                prs.setString(2, "Sent -" + dAmoutpay + " to " + payeeName + "\t" +  "Date: " + formattedDateTime);
                prs.setString(3, transID1);
                prs.executeUpdate();


                //the user who recieve
                Database db02 = new Database();
                Connection connectDB02 = db02.getLink();
                String usl1 = "INSERT INTO transactiontable (accountnumber, sendorrecieve, id) VALUES (?, ?, ?)";
                PreparedStatement prs1 = connectDB02.prepareStatement(usl1);
                prs1.setString(1, payee.getText());
                prs1.setString(2, "Recieve +" + dAmoutpay + " from " + us.getCurrentFullname() + "\t" + "Date: " + formattedDateTime);
                prs1.setString(3, transID2);
                prs1.executeUpdate();

                alert.showAndWait();
                dashboardBtn(e);
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText("Not found!");
                alert.setContentText("Card number not found!");
                alert.showAndWait();
                return;
            }

        } catch (SQLException ex) {
            connectDB4.rollback(); // Rollback transaction on error
            ex.printStackTrace();
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        } finally {
            connectDB4.setAutoCommit(true); // Reset auto-commit mode
            connectDB4.close();
        }
    }catch (Exception ef){}
            }
        });

    }


    public void logOUT(ActionEvent e) throws IOException {
        FXMLLoader logoutLoader = new FXMLLoader(Main.class.getResource("loginScreen.fxml"));
        Stage logoutStage  = (Stage)((Node)e.getSource()).getScene().getWindow();
        Scene logoutScene = new Scene(logoutLoader.load());
        logoutStage.setScene(logoutScene);
        logoutStage.show();
    }

    public void sendMessageEmail(String mess,String amount){
        UserSession userSession = UserSession.getInstance();
        String subject = "epay.ph-noreply@gmail.com";
        String body = "You recieved money of PHP "+amount+" from "+userEA+" ! \nSent Message: "+mess+" \nTransaction ID " + userSession.getTransactioID() +"\nPlease login in Epay.PH to check your new Balance!\n\n\nRegards, Epay.PH ";

        String host = "smtp.gmail.com";
        final String username = "www.epay.ph@gmail.com";
        final String password3 = "yock jasy ojrb esbp";

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", host);
        props.put("mail.smtp.port", "587");

        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication(){
                return new PasswordAuthentication(username, password3);
            }
        });

        try{
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress("www.epay.ph@gmail.com"));
            message.setRecipient(Message.RecipientType.TO, new InternetAddress(payeeEmail));
            message.setSubject(subject);
            message.setText(body);

            Transport.send(message);
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }


    //Signup section


    @FXML
    private TextField firstname;
    @FXML
    private TextField lastname;
    @FXML
    private TextField mobileOrEmail;
    @FXML
    private PasswordField password;
    @FXML
    private DatePicker birthday;
    @FXML
    private ToggleGroup gender;
    @FXML
    private RadioButton maleBtn;
    @FXML
    private RadioButton femaleBtn;
    @FXML
    private RadioButton Other;
    @FXML
    private Button SignUpCreateAccount;
    @FXML
    private Label signupMessage;

    public void validateSignUp(ActionEvent e) throws Exception {


        LocalDate selectedBirthday = birthday.getValue();

        if(!firstname.getText().isBlank() && !lastname.getText().isBlank() && !mobileOrEmail.getText().isBlank() && !password.getText().isBlank() &&  (gender != null) && (selectedBirthday != null)){
            String strFullname = firstname.getText() + " " + lastname.getText();
            String strMobileOrEmail = mobileOrEmail.getText();
            String strPassword = password.getText();
            String strBirthday = selectedBirthday.toString();
            String strGender = "";

            if(firstname.getText().length() == 1 && !firstname.getText().matches("[a-zA-Z ]")){
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error!");
                alert.setHeaderText("Invalid!");
                alert.setContentText("Invalid Firstname!");
                alert.showAndWait();
                return;
            }
            if(lastname.getText().length() == 1 && !lastname.getText().matches("[a-zA-Z ]")){
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error!");
                alert.setHeaderText("Invalid!");
                alert.setContentText("Invalid Lastname!");
                alert.showAndWait();
                return;
            }
            String lengthOfBday = selectedBirthday.toString();
            if(lengthOfBday.length() != 10){
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error!");
                alert.setHeaderText("Invalid!");
                alert.setContentText("Invalid Birthday!");
                alert.showAndWait();
                return;
            }


            if(strPassword.length() != 8 || password1.getText().length() != 8){
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error!");
                alert.setHeaderText("Invalid!");
                alert.setContentText("Password must be 8 characters!");
                alert.showAndWait();
                return;
            }

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date birthDate = null;
            try {
                birthDate = sdf.parse(String.valueOf(selectedBirthday));
            } catch (Exception ey) {
                ey.printStackTrace();
                return;
            }

            // Get current date
            Date currentDate = new Date();

            // Calculate age
            Calendar birthCal = Calendar.getInstance();
            birthCal.setTime(birthDate);

            Calendar currentCal = Calendar.getInstance();
            currentCal.setTime(currentDate);

            int age = currentCal.get(Calendar.YEAR) - birthCal.get(Calendar.YEAR);

            // If current date is before the birth date this year, subtract one year from age
            if (currentCal.get(Calendar.MONTH) < birthCal.get(Calendar.MONTH) ||
                    (currentCal.get(Calendar.MONTH) == birthCal.get(Calendar.MONTH) &&
                            currentCal.get(Calendar.DAY_OF_MONTH) < birthCal.get(Calendar.DAY_OF_MONTH))) {
                age--;
            }

            // Check if underage
            if (age < 18) {
                Alert al = new Alert(Alert.AlertType.ERROR);
                al.setTitle("Underage");
                al.setHeaderText(null);
                al.setContentText("You are underage!");
                al.showAndWait();
                return;
            }



            String strAge = String.valueOf(age); // years old



            if(femaleBtn.isSelected()){
                strGender = "Female";
            }else if(maleBtn.isSelected()){
                strGender = "Male";
            }else{
                strGender = "Other";
            }


            registerController rc = new registerController();
            rc.registerAccount(strFullname, strMobileOrEmail, strPassword, strBirthday, strGender, strAge);
        }else{
            signupMessage.setText("All Textfields are required!");
        }

    }
    public static final String Acc_SID = "ACdf501ab6c4476c11dbe6b3c41bcecec0";
    public static final String Acc_Token = "493ce97ad5de2f3c63b8f71c2aed6160";


    //forgotpass section
    public void forgotPassOnAction(ActionEvent e) throws IOException {
        FXMLLoader forgotPassLoader = new FXMLLoader(Main.class.getResource("forgotPassScreen.fxml"));
        Stage forgotpassStage = (Stage)((Node) e.getSource()).getScene().getWindow();
        Scene forgotpassScene = new Scene(forgotPassLoader.load());
        forgotpassStage.setScene(forgotpassScene);
        forgotpassStage.show();
    }
    public void profileBtn(ActionEvent e) throws IOException, SQLException {
        profileController pc = new profileController();
        pc.profile(e);
    }

    @FXML
    private TextField password1;
    @FXML
    private CheckBox showPass;
    @FXML
    public void setShowPass(ActionEvent e){
        if(showPass.isSelected()){
            password1.setText(password.getText());
            password1.setVisible(true);
            password.setVisible(false);
            return;
        }
        password.setText(password1.getText());
        password.setVisible(true);
        password1.setVisible(false);
    }

    public void gotoAccountTab(ActionEvent e) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("accountTab.fxml"));
        Parent root = loader.load();
        Scene scene = new Scene(root);
        Stage stage = (Stage) nameID.getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }


//bulksms
//    public void PhonenumberOTP (String phNumber, String smsMessage) throws IOException, URISyntaxException {
//        String myURI = "https://api.bulksms.com/v1/messages";
//
//        // change these values to match your own account
//        String myUsername = "epayph";
//        String myPassword = "epayPH1640";
//
//        // the details of the message we want to send
//        String myData = "{to: \""+phNumber+"\", encoding: \"UNICODE\", body: \""+smsMessage+"\"}";
//
//        // if your message does not contain unicode, the "encoding" is not required:
//        // String myData = "{to: \"1111111\", body: \"Hello Mr. Smith!\"}";
//
//        // build the request based on the supplied settings
//        URI uri = new URI(myURI);
//        URL url = uri.toURL();
//        HttpURLConnection request = (HttpURLConnection) url.openConnection();
//        request.setDoOutput(true);
//
//        // supply the credentials
//        String authStr = myUsername + ":" + myPassword;
//        String authEncoded = Base64.getEncoder().encodeToString(authStr.getBytes());
//        request.setRequestProperty("Authorization", "Basic " + authEncoded);
//
//        // we want to use HTTP POST
//        request.setRequestMethod("POST");
//        request.setRequestProperty( "Content-Type", "application/json");
//
//        // write the data to the request
//        OutputStreamWriter out = new OutputStreamWriter(request.getOutputStream());
//        out.write(myData);
//        out.close();
//
//        // try ... catch to handle errors nicely
//        try {
//            // make the call to the API
//            InputStream response = request.getInputStream();
//            BufferedReader in = new BufferedReader(new InputStreamReader(response));
//            String replyText;
//            while ((replyText = in.readLine()) != null) {
//                System.out.println(replyText);
//            }
//            in.close();
//        } catch (IOException ex) {
//            System.out.println("An error occurred:" + ex.getMessage());
//            BufferedReader in = new BufferedReader(new InputStreamReader(request.getErrorStream()));
//            // print the detail that comes with the error
//            String replyText;
//            while ((replyText = in.readLine()) != null) {
//                System.out.println(replyText);
//            }
//            in.close();
//        }
//        request.disconnect();
//    }



//    private static Message prepareMessage(Session session, String rep, String OTPcode){
//        try{
//            Message message = new MimeMessage(session);
//            message.setFrom(new InternetAddress("www.epay.ph@gmail.com"));
//            message.setRecipient(Message.RecipientType.TO, new InternetAddress(rep));
//            message.setSubject("One Time Password from Epay.PH Official");
//            message.setText("Your OTP Code: " + OTPcode);
//        }catch (Exception ex){
//            ex.printStackTrace();
//        }
//        return  null;
//    }
//    @FXML
//    private Button scene1Btn;
//    @FXML
//    private Button scene2Btn;
//    private Stage stage;
//    private Scene scene;
//    public void scene1Window(ActionEvent e) throws IOException {
//        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("scene1.fxml"));
//        stage = (Stage)((Node)e.getSource()).getScene().getWindow();
//        scene = new Scene(fxmlLoader.load());
//        stage.setScene(scene);
//        stage.show();
//
//    }
//    public void scene2Window(ActionEvent e) throws IOException {
//        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("scene2.fxml"));
//        stage = (Stage)((Node)e.getSource()).getScene().getWindow();
//        scene = new Scene(fxmlLoader.load());
//        stage.setScene(scene);
//        stage.show();
//    }

}