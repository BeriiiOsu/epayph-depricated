package com.main.epayphmain;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Properties;

public class emailSender {
    public void sendEmail(String HeaderMess, String mess, String email){
        String host = "smtp.gmail.com";
        final String username = "www.epay.ph@gmail.com";
        final String password3 = "yock jasy ojrb esbp";

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", host);
        props.put("mail.smtp.port", "587");

        Session session1 = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password3);
            }
        });

        try {
            Message message = new MimeMessage(session1);
            message.setFrom(new InternetAddress("www.epay.ph@gmail.com"));
            message.setRecipient(Message.RecipientType.TO, new InternetAddress(email));
            message.setSubject(HeaderMess);
            message.setText(mess);

            Transport.send(message);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
