package com.main.epayphmain;

public class holderSingleton {
    private static final holderSingleton instance = new holderSingleton();
    private holderSingleton() {}
    public static holderSingleton getInstance() {
        return instance;
    }
    private String txtEmail;
    private String txtPassword;
    private boolean showMode = false;

    public void setShowMode(boolean showMode) { this.showMode = showMode; }
    public boolean getShowMode() { return showMode; }

    public void setTxtPassword(String txtPassword) { this.txtPassword = txtPassword; }
    public String getTxtPassword(){ return txtPassword; }


    public void setTxtEmail(String txtEmail){ this.txtEmail = txtEmail; }
    public String getTxtEmail(){ return txtEmail; }

}
