package com.main.epayphmain;

import com.cathive.fonts.fontawesome.FontAwesomeIcon;
import com.cathive.fonts.fontawesome.FontAwesomeIconView;
import com.twilio.rest.chat.v1.service.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

public class accountTabController {

    @FXML
    private VBox transactionBox;

    @FXML
    private ScrollPane scrollPane;

    @FXML
    private Label savingsLBL;
    @FXML
    private Label accnoLBL;
    @FXML
    private Label validLBL;
    @FXML
    private Label cvcLBL;
    @FXML
    private Label savingsbalanceLBL;


    public void initialize() throws SQLException {
        UserSession userSession = UserSession.getInstance();
        Database db = new Database();
        Connection connection = db.getLink();
        String url = "select cardnumber,savingsnumber,savingsbalance,cvc,validthru from epaytable where emailaddress = ?";
        PreparedStatement ps = connection.prepareStatement(url);
        ps.setString(1, userSession.getCurrentEmail());
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            accnoLBL.setText(rs.getString("cardnumber"));
            savingsLBL.setText(rs.getString("savingsnumber"));
            savingsbalanceLBL.setText(String.valueOf(rs.getDouble("savingsbalance")));
            cvcLBL.setText(rs.getString("cvc"));
            validLBL.setText(rs.getString("validthru"));
        }

        performTransaction();
    }


    private void performTransaction() throws SQLException {
        UserSession us = UserSession.getInstance();

        Database db = new Database();
        Connection connection = db.getLink();
        String transactionDetail = "";
        String id = "";
        String accountNumber = us.getUserCardNumber();

        String url = "select sendorrecieve,id from transactiontable where accountnumber = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(url);
        preparedStatement.setString(1, accountNumber);
        ResultSet resultSet = preparedStatement.executeQuery();
        while(resultSet.next()) {
            transactionDetail = resultSet.getString("sendorrecieve");
            id = resultSet.getString("id");
            handleTransaction(accountNumber, transactionDetail, id); // This would be dynamic in a real scenario
        }
        updateUI(accountNumber, transactionBox, scrollPane);
    }

    public void handleTransaction(String accountNumber, String transactionDetail, String id) {
        String directoryPath = "C:\\Java Project\\epaydemo1\\data";
        File directory = new File(directoryPath);

        String fileName = directoryPath + File.separator + accountNumber + ".txt";

        Path path = Paths.get(fileName);
        if(Files.exists(path)){
                try {
                    Files.delete(path);
                } catch (IOException e) {
                    System.err.println("Failed to delete the file: " + fileName);
                    e.printStackTrace();
                }
        }
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true))) {
                writer.write(transactionDetail + " ID: " + id);
                writer.newLine();
            } catch (IOException e) {
                e.printStackTrace();
            }



    }

    public List<String> readTransactions(String accountNumber) {
        String directoryPath = "C:\\Java Project\\epaydemo1\\data";
        String fileName = directoryPath + File.separator + accountNumber + ".txt";
        List<String> transactions = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                transactions.add(line);
            }
        } catch (IOException e) {}
        return transactions;
    }

    public void updateUI(String accountNumber, VBox transactionBox, ScrollPane scrollPane) throws SQLException {
        UserSession userSession = UserSession.getInstance();
        Database db = new Database();
        Connection connection = db.getLink();
        String url = "select cardnumber,savingsnumber,savingsbalance,cvc,validthru from epaytable where emailaddress = ?";
        PreparedStatement ps = connection.prepareStatement(url);
        ps.setString(1, userSession.getCurrentEmail());
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            accnoLBL.setText(rs.getString("cardnumber"));
            savingsLBL.setText(rs.getString("savingsnumber"));
            savingsbalanceLBL.setText(String.valueOf(rs.getDouble("savingsbalance")));
            cvcLBL.setText(rs.getString("cvc"));
            validLBL.setText(rs.getString("validthru"));
        }


        transactionBox.getChildren().clear();
        List<String> transactions = readTransactions(accountNumber);

        for (String transaction : transactions) {
            HBox hBox = new HBox();
            hBox.setSpacing(10);
            hBox.setAlignment(Pos.CENTER_LEFT);
            hBox.setPadding(new Insets(5, 5, 5, 5));

            String transactionDetail = extractTransactionDetail(transaction);

            Text transactionText = new Text(transactionDetail);
            transactionText.setStyle("-fx-font-weight: bold; -fx-background-color: white; -fx-background-radius: 10px; -fx-border-color: black; -fx-border-radius: 10px; -fx-padding: 5px; -fx-wrap-text: true; -fx-font-size: 8px");

            String transactionID = extractTransactionID(transaction);


            FontAwesomeIconView fontAwesomeIconView = new FontAwesomeIconView();
            fontAwesomeIconView.setIcon(FontAwesomeIcon.ICON_REMOVE);
            fontAwesomeIconView.setStyle("-fx-fill: red; -fx-font-size: 10px;");
            Button removeButton = new Button();
            removeButton.setStyle("-fx-background-color: white; -fx-text-fill: red; -fx-background-radius: 10px; -fx-border-color: black; -fx-border-radius: 10px;");
            removeButton.setGraphic(fontAwesomeIconView);
            removeButton.setOnAction(e -> {
                transactionBox.getChildren().remove(hBox);
                try {
                    removeTransaction(accountNumber, transactionID);
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
            });

            Pane spacer = new Pane();
            HBox.setHgrow(spacer, Priority.ALWAYS);

            hBox.getChildren().addAll(transactionText, spacer, removeButton);
            transactionBox.getChildren().add(hBox);
        }
        scrollPane.setContent(transactionBox);
    }

    private String extractTransactionID(String transaction){
        int startIndex = transaction.indexOf("ID: ") + "ID: ".length();
        return transaction.substring(startIndex);
    }
    private String extractTransactionDetail(String transaction) {
        int endIndex = transaction.indexOf("ID: ");
        if (endIndex == -1) return transaction;
        return transaction.substring(0, endIndex).trim();
    }
    private void removeTransaction(String accountNumber, String transactionID) throws SQLException {
        String directoryPath = "C:\\Java Project\\epaydemo1\\data";
        String fileName = directoryPath + File.separator + accountNumber + ".txt";
        File tempFile = new File(directoryPath + File.separator + accountNumber + "_temp.txt");

        try (BufferedReader reader = new BufferedReader(new FileReader(fileName));
             BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))) {

            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.contains("ID: " + transactionID)) {
                    writer.write(line);
                    writer.newLine();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        File originalFile = new File(fileName);
        if (originalFile.delete()) {
            tempFile.renameTo(originalFile);
        }

        Database database = new Database();
        Connection connection = database.getLink();
        connection.setAutoCommit(false);
        String usage = "delete from transactiontable where accountnumber = ? and id = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(usage);
        preparedStatement.setString(1, accountNumber);
        preparedStatement.setString(2, transactionID);
        preparedStatement.executeUpdate();
        connection.commit();
        connection.setAutoCommit(true);
        connection.close();

        Path path = Paths.get(fileName);
        if (Files.exists(path)) {
            try {
                Files.delete(path);
            } catch (IOException e) {
                System.err.println("Failed to delete the file: " + fileName);
                e.printStackTrace();
            }
        }
    }


    public void gotoDashboard(ActionEvent e) throws SQLException, IOException {
        Controller c = new Controller();
        c.dashboardBtn(e);
    }

    public void logoutBTN(ActionEvent e) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("loginScreen.fxml"));
        Parent root = loader.load();
        Scene scene = new Scene(root);
        Stage stage = (Stage) transactionBox.getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    public void gotoProfile(ActionEvent e) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("profileScreen.fxml"));
        Parent root = loader.load();
        Scene scene = new Scene(root);
        Stage stage = (Stage) transactionBox.getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    public void gotoAccountTab(ActionEvent e) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("accountTab.fxml"));
        Parent root = loader.load();
        Scene scene = new Scene(root);
        Stage stage = (Stage) transactionBox.getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    public void transfertoATM(ActionEvent e) throws SQLException, IOException {
        UserSession userSession = UserSession.getInstance();
        Database db = new Database();
        Connection connection = db.getLink();
        String url = "select savingsbalance from epaytable where savingsnumber = ?";
        double currentSBAL = 0.0;
        PreparedStatement preparedStatement = connection.prepareStatement(url);
        preparedStatement.setString(1, userSession.getSavingsnumber());
        ResultSet rs = preparedStatement.executeQuery();
        if (rs.next()) {
            currentSBAL = rs.getDouble("savingsbalance");
        }
        userSession.setSavingsbal(currentSBAL);

        Database db1 = new Database();
        Connection connection1 = db1.getLink();
        String url1 = "select balance from epaytable where cardnumber = ?";
        double currentABAL = 0.0;
        PreparedStatement preparedStatement1 = connection1.prepareStatement(url1);
        preparedStatement1.setString(1, userSession.getCardnumber());
        ResultSet rs1 = preparedStatement1.executeQuery();
        if (rs1.next()) {
            currentABAL = rs1.getDouble("balance");
        }
        userSession.setCardnoBal(currentABAL);

        double sBal = userSession.getSavingsbal();
        double aBal = userSession.getCardnoBal();


        Dialog<String> dialog = new Dialog<>();
        dialog.setTitle("Transfer to ATM?");
        dialog.setHeaderText(null);

        TextField amount = new TextField();
        amount.setPromptText("Amount");

        VBox content = new VBox(10, new Label("Enter an amount:"), amount);
        content.setAlignment(Pos.CENTER);
        dialog.getDialogPane().setContent(content);

        ButtonType submitBtn = new ButtonType("Confirm", ButtonBar.ButtonData.OK_DONE);
        ButtonType cancelBtn = new ButtonType("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);
        dialog.getDialogPane().getButtonTypes().addAll(submitBtn, cancelBtn);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == submitBtn) {
                return amount.getText();
            }
            return null;
        });

        dialog.showAndWait().ifPresent(theAmount -> {
            if(!theAmount.matches("[0-9]+")){
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error!");
                alert.setHeaderText("Invalid!");
                alert.setContentText("Enter a number.");
                alert.showAndWait();
                return;
            }
            double transferAmount = new BigDecimal(theAmount).setScale(2, RoundingMode.HALF_UP).doubleValue();
            if (transferAmount > sBal) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error!");
                alert.setHeaderText("Invalid!");
                alert.setContentText("Insufficient Balance.");
                alert.showAndWait();
                return;
            } else if(transferAmount <= 0){
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error!");
                alert.setHeaderText("Invalid!");
                alert.setContentText("Please enter a valid amount.");
                alert.showAndWait();
                return;
            }else{
                double newSavings = sBal - transferAmount;

                double newAtm = aBal + transferAmount;

                try {
                    Database db3 = new Database();
                    Connection connection2 = db3.getLink();
                    connection2.setAutoCommit(false);
                    String x = "update epaytable set savingsbalance = ?, balance = ? where emailaddress = ?";
                    PreparedStatement ps = null;

                    ps = connection2.prepareStatement(x);

                    ps.setDouble(1, newSavings);
                    ps.setDouble(2, newAtm);
                    ps.setString(3, userSession.getCurrentEmail());
                    ps.executeUpdate();
                    connection2.commit();
                    connection2.setAutoCommit(true);
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });
        FXMLLoader loader = new FXMLLoader(getClass().getResource("accountTab.fxml"));
        Parent root = loader.load();
        Scene scene = new Scene(root);
        Stage stage = (Stage) transactionBox.getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    public void transfertoSA(ActionEvent e) throws SQLException, IOException {
        UserSession userSession = UserSession.getInstance();
        Database db = new Database();
        Connection connection = db.getLink();
        String url = "select savingsbalance from epaytable where savingsnumber = ?";
        double currentSBAL = 0.0;
        PreparedStatement preparedStatement = connection.prepareStatement(url);
        preparedStatement.setString(1, userSession.getSavingsnumber());
        ResultSet rs = preparedStatement.executeQuery();
        if (rs.next()) {
            currentSBAL = rs.getDouble("savingsbalance");
        }
        userSession.setSavingsbal(currentSBAL);

        Database db1 = new Database();
        Connection connection1 = db1.getLink();
        String url1 = "select balance from epaytable where cardnumber = ?";
        double currentABAL = 0.0;
        PreparedStatement preparedStatement1 = connection1.prepareStatement(url1);
        preparedStatement1.setString(1, userSession.getCardnumber());
        ResultSet rs1 = preparedStatement1.executeQuery();
        if (rs1.next()) {
            currentABAL = rs1.getDouble("balance");
        }
        userSession.setCardnoBal(currentABAL);

        double sBal = userSession.getSavingsbal();
        double aBal = userSession.getCardnoBal();


        Dialog<String> dialog = new Dialog<>();
        dialog.setTitle("Transfer to ATM?");
        dialog.setHeaderText(null);

        TextField amount = new TextField();
        amount.setPromptText("Amount");

        VBox content = new VBox(10, new Label("Enter an amount:"), amount);
        content.setAlignment(Pos.CENTER);
        dialog.getDialogPane().setContent(content);

        ButtonType submitBtn = new ButtonType("Confirm", ButtonBar.ButtonData.OK_DONE);
        ButtonType cancelBtn = new ButtonType("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);
        dialog.getDialogPane().getButtonTypes().addAll(submitBtn, cancelBtn);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == submitBtn) {
                return amount.getText();
            }
            return null;
        });

        dialog.showAndWait().ifPresent(theAmount -> {
            if(!theAmount.matches("[0-9]+")){
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error!");
                alert.setHeaderText("Invalid!");
                alert.setContentText("Enter a number.");
                alert.showAndWait();
                return;
            }
            double transferAmount = new BigDecimal(theAmount).setScale(2, RoundingMode.HALF_UP).doubleValue();
            if (transferAmount > sBal) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error!");
                alert.setHeaderText("Invalid!");
                alert.setContentText("Insufficient Balance.");
                alert.showAndWait();
                return;
            } else if(transferAmount <= 0){
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error!");
                alert.setHeaderText("Invalid!");
                alert.setContentText("Please enter a valid amount.");
                alert.showAndWait();
                return;
            }else{
                double newSavings = sBal + transferAmount;

                double newAtm = aBal - transferAmount;

                try {
                    Database db3 = new Database();
                    Connection connection2 = db3.getLink();
                    connection2.setAutoCommit(false);
                    String x = "update epaytable set savingsbalance = ?, balance = ? where emailaddress = ?";
                    PreparedStatement ps = null;

                    ps = connection2.prepareStatement(x);

                    ps.setDouble(1, newSavings);
                    ps.setDouble(2, newAtm);
                    ps.setString(3, userSession.getCurrentEmail());
                    ps.executeUpdate();
                    connection2.commit();
                    connection2.setAutoCommit(true);
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });
        FXMLLoader loader = new FXMLLoader(getClass().getResource("accountTab.fxml"));
        Parent root = loader.load();
        Scene scene = new Scene(root);
        Stage stage = (Stage) transactionBox.getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }


}
