package com.main.epayphmain;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.IOException;
import java.sql.*;
import java.util.Properties;
import java.util.Random;

public class linkAccount {
    boolean isSuccess = false;
    private String codes;
    private String pwd;
    private String bdy;
    private String eml;
    private boolean isMail;
    @FXML
    private TextField cardNumberInput;
    @FXML
    private TextField validThruInput;
    @FXML
    private TextField cvcInput;

    boolean condition = false;
    boolean isCorrectCN = false;
    static String strCN = "";
    static String strVT = "";
    static String strCVC = "";
    public void validateInfo() throws SQLException {
        if(cardNumberInput.getText().length() == 16){
            strCN = cardNumberInput.getText();
            if (validThruInput.getText().matches("^\\d+/\\d+$")) {
                if(validThruInput.getText().length() == 5){
                    strVT = validThruInput.getText();
                    if (cvcInput.getText().length() == 3){
                        strCVC = cvcInput.getText();

                        Database db2 = new Database();
                        Connection connectDB2 = db2.getLink();

                        String finder = "SELECT count(1) FROM epaytable WHERE cardnumber = ? AND validthru = ? AND cvc = ?";
                        PreparedStatement pt = connectDB2.prepareStatement(finder);
                        pt.setString(1, cardNumberInput.getText());
                        pt.setString(2, validThruInput.getText());
                        pt.setString(3, cvcInput.getText());

                        ResultSet findResult = pt.executeQuery();

                        if (findResult.next() && findResult.getInt(1) == 1) {
                            condition = true;

                        }else{
                            alertBox("Card not found!");
                        }



                    }else{
                        alertBox("Please enter the correct CVC!");
                    }
                }else{
                    alertBox("Please enter a valid date!");
                }

            }else{
                alertBox("Please enter the correct format!");
            }

        } else {
            alertBox("Please input your 16 digit Card Number!");
        }


    }

    public void cancelBtnLink(ActionEvent e) throws IOException {
        Main mainApp = Main.getInstance();
        mainApp.switchScene("signupScreen.fxml");
//        FXMLLoader goBackLogin = new FXMLLoader(Main.class.getResource("loginScreen.fxml"));
//        Stage st = (Stage)((Node) e.getSource()).getScene().getWindow();
//        Scene sc = new Scene(goBackLogin.load());
//        st.setScene(sc);
//        st.show();
    }
//    public void confirmBtn(ActionEvent e) throws SQLException {
//            validateInfo();
//    }
//    public void switchLink(){
//        Main mainApp = Main.getInstance();
//        mainApp.switchScene("accountLink.fxml");
//    }


//    String passWord, String bday,String email, boolean isEmail
    public void passINFO() throws SQLException {
        Main mainApp = Main.getInstance();
        mainApp.switchScene("accountLink.fxml");
//        switchLink();

    }

    public void checkEmail(String passWord,String bday,String email,boolean isEmail) throws SQLException {
        Database connectNow1 = new Database();
        Connection db1 = connectNow1.getLink();
        db1.setAutoCommit(false);
            String sql = "update epaytable set password = ?, birthday = ?, phonenumber = ? where cardnumber = '" + strCN + "' ";
            try {
                PreparedStatement pstmt = db1.prepareStatement(sql);
                pstmt.setString(1, passWord);
                pstmt.setString(2, bday);
                pstmt.setString(3, email);

                if (isEmail) {
                    String code = otpGenerator();
                    codes = code;

                    String host = "smtp.gmail.com";
                    final String username = "www.epay.ph@gmail.com";
                    final String password3 = "yock jasy ojrb esbp";

                    Properties props = new Properties();
                    props.put("mail.smtp.auth", "true");
                    props.put("mail.smtp.starttls.enable", "true");
                    props.put("mail.smtp.host", host);
                    props.put("mail.smtp.port", "587");

                    Session session = Session.getInstance(props, new Authenticator() {
                        @Override
                        protected PasswordAuthentication getPasswordAuthentication() {
                            return new PasswordAuthentication(username, password3);
                        }
                    });

                    try {
                        Message message = new MimeMessage(session);
                        message.setFrom(new InternetAddress("www.epay.ph@gmail.com"));
                        message.setRecipient(Message.RecipientType.TO, new InternetAddress(email));
                        message.setSubject("Card Number Account Link | Epay.PH Official");
                        message.setText("Your OTP Code: " + codes);

                        Transport.send(message);
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
//                Message message = prepareMessage(session, strEmail, code);
//                assert message != null;

                } else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Notice!");
                    alert.setContentText("Phone number is under development!");
                    alert.showAndWait();
                    //withfalse noon
                    return;
//                phoneNumberSender pns = new phoneNumberSender();
//                pns.PhoneNumber(Acc_SID, Acc_Token, strPhoneNumber,mesOTP);
                    //PhoneNumber(Acc_SID, Acc_Token, strPhoneNumber,mesOTP);
//                PhonenumberOTP(strPhoneNumber, mesOTP);
                }

                Dialog<String> dialog = new Dialog<>();
                dialog.setTitle("Enter OTP");
                dialog.setHeaderText("Please enter the OTP code:");

                TextField otpTxtfield = new TextField();
                otpTxtfield.setPromptText("6 Digit Code");

                VBox content = new VBox(10, new Label("OTP:"), otpTxtfield);
                content.setAlignment(Pos.CENTER);
                dialog.getDialogPane().setContent(content);

                ButtonType submitBtn = new ButtonType("Submit", ButtonBar.ButtonData.OK_DONE);
                ButtonType cancelBtn = new ButtonType("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);
                dialog.getDialogPane().getButtonTypes().addAll(submitBtn, cancelBtn);

                dialog.setResultConverter(dialogButton -> {
                    if (dialogButton == submitBtn) {
                        return otpTxtfield.getText();
                    }
                    return null;
                });

                dialog.showAndWait().ifPresent(otpCode -> {
                    if (codes.equals(otpCode)) {
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Success!");
                        alert.setHeaderText("Success!");
                        alert.setContentText("OTP verification successful!");
                        alert.showAndWait();
                        isSuccess = true;

                    } else {
                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.setTitle("Error!");
                        alert.setHeaderText("Invalid!");
                        alert.setContentText("Invalid OTP. Please try again.");
                        alert.showAndWait();
                        isSuccess = false;
                    }
                });

                if (isSuccess) {
                    int update = pstmt.executeUpdate();
                    db1.commit();
                    db1.setAutoCommit(true);
                    db1.close();
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Notice!");
                    alert.setHeaderText("Success!");
                    alert.setContentText("Account Created!" + "\nTrace number: "+update);
                    alert.showAndWait();
                    Main mainApp = Main.getInstance();
                    mainApp.switchScene("loginScreen.fxml");

//                    Database db7 = new Database();
//                    Connection connectDB7 = db7.getLink();
//                    String deleteRow = "DELETE from epaytable where emailaddress = ? AND password IS NULL AND birthday IS NULL";
//                    PreparedStatement pt2 = connectDB7.prepareStatement(deleteRow);
//                    pt2.executeUpdate(deleteRow);
//                    pt2.close();
//                    connectDB7.close();
                }
            } catch (SQLIntegrityConstraintViolationException e) {
                e.printStackTrace();
//                Alert alert = new Alert(Alert.AlertType.ERROR);
//                alert.setTitle("Account already exists.");
//                alert.setContentText("Phone number or Email already exists. Please use a different phone number or email.");
//                alert.showAndWait();
            } catch (Exception e) {
                e.printStackTrace();
            }
            //return true noon
//        return true;
    }

    public String otpGenerator(){
        Random random = new Random();
        int otp = random.nextInt(1000000);
        return String.format("%06d", otp);
    }
    public void alertBox(String content){
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }


}
