package com.main.epayphmain;
import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
import javafx.scene.control.Alert;


public class phoneNumberSender {
    public void PhoneNumber(String sid, String authToken,String phNum,String coded){

        Twilio.init(sid, authToken);
        Message message = Message.creator(
                new PhoneNumber(phNum),
                new PhoneNumber("+639454587967"),
                coded
        ).create();

        Alert alert  = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Sent!");
        alert.setHeaderText("OTP sent!");
        alert.setContentText(message.getSid());
        alert.showAndWait();
    }
}
