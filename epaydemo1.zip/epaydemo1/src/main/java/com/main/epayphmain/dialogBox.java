package com.main.epayphmain;

import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;

import java.util.concurrent.atomic.AtomicBoolean;

public class dialogBox {
    public boolean getAlertOTPBox(String codes){
        Dialog<String> dialog = new Dialog<>();
        dialog.setTitle("Enter OTP");
        dialog.setHeaderText("Please enter the OTP code:");

        TextField otpTxtfield = new TextField();
        otpTxtfield.setPromptText("6 Digit Code");

        VBox content = new VBox(10, new Label("OTP:"), otpTxtfield);
        content.setAlignment(Pos.CENTER);
        dialog.getDialogPane().setContent(content);

        ButtonType submitBtn = new ButtonType("Submit", ButtonBar.ButtonData.OK_DONE);
        ButtonType cancelBtn = new ButtonType("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);
        dialog.getDialogPane().getButtonTypes().addAll(submitBtn, cancelBtn);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == submitBtn) {
                return otpTxtfield.getText();
            }
            return null;
        });

        AtomicBoolean isSuccess = new AtomicBoolean(false);
        dialog.showAndWait().ifPresent(otpCode -> {
            if (codes.equals(otpCode)) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Success!");
                alert.setHeaderText("Success!");
                alert.setContentText("OTP verification successful!");
                alert.showAndWait();
                isSuccess.set(true);

            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error!");
                alert.setHeaderText("Invalid!");
                alert.setContentText("Invalid OTP. Please try again.");
                alert.showAndWait();
                isSuccess.set(false);
            }
        });
        return isSuccess.get();
    }
}
