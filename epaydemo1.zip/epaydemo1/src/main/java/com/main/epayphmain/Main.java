package com.main.epayphmain;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import java.io.IOException;

@SuppressWarnings("ALL")
public class Main extends Application {
    private static Stage primaryStage;
    private static Main instance;

    @Override
    public void start(Stage primaryStage) throws IOException {
        Main.primaryStage = primaryStage;
        instance = this;
        mainScene();
    }

    public void mainScene() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("loginScreen.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 600, 400);
//        scene.getStylesheets().add(String.valueOf(Main.class.getResource("application.css")));
        primaryStage.setTitle("Epay.PH");
        Image icon = new Image("file:C:\\Java Project\\epaydemo1\\src\\epaylogo.png");
        primaryStage.getIcons().add(icon);
        primaryStage.setResizable(false);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public void switchScene(String fxmlFile) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            primaryStage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Main getInstance() {
        return instance;
    }

    public static void main(String[] args) {
        launch();
    }
}
