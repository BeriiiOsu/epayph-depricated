package com.main.epayphmain;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.IOException;
import java.sql.*;
import java.util.Properties;
import java.util.Random;

public class forgotPassController {
    //forgotpass section
    boolean isSuccess = false;
    @FXML
    private TextField searchInput;
    @FXML
    private Button cancelBtnForgotPass;
    @FXML
    private Button searchBtn;


    public void setcancelForgotBackBtn(ActionEvent e) throws IOException{
        FXMLLoader forgotPassLoader = new FXMLLoader(Main.class.getResource("loginScreen.fxml"));
        Stage forgotpassStage  = (Stage)((Node)e.getSource()).getScene().getWindow();
        Scene forgotpassScene = new Scene(forgotPassLoader.load());
        forgotpassStage.setScene(forgotpassScene);
        forgotpassStage.show();
    }
    public void setSearchBtn() throws SQLException {
        Database db = new Database();
        Connection connectionDB = db.getLink();



        String searchEmailStatement = "select count(1) from epaytable where emailaddress = '" + searchInput.getText() + "' ";
        String searchNumberStatement = "select count(1) from epaytable where phonenumber = '" + searchInput.getText() + "' ";
        Statement emailS = connectionDB.createStatement();
        Statement numberS = connectionDB.createStatement();



        if(searchInput.getText().contains("@")){
            ResultSet rs = emailS.executeQuery(searchEmailStatement);
            while (rs.next()){
                if(rs.getInt(1) == 1){


                    String code = otpGenerator();

                    String host = "smtp.gmail.com";
                    final String username = "www.epay.ph@gmail.com";
                    final String password3 = "yock jasy ojrb esbp";

                    Properties props = new Properties();
                    props.put("mail.smtp.auth", "true");
                    props.put("mail.smtp.starttls.enable", "true");
                    props.put("mail.smtp.host", host);
                    props.put("mail.smtp.port", "587");

                    Session session = Session.getInstance(props, new Authenticator() {
                        @Override
                        protected PasswordAuthentication getPasswordAuthentication(){
                            return new PasswordAuthentication(username, password3);
                        }
                    });

                    try{
                        Message message = new MimeMessage(session);
                        message.setFrom(new InternetAddress("www.epay.ph@gmail.com"));
                        message.setRecipient(Message.RecipientType.TO, new InternetAddress(searchInput.getText()));
                        message.setSubject("One Time Password: Change password from Epay.PH Official");
                        message.setText("You are attempting to change your password in Epayph. You can simply ignore this email if it's not you. \nYour OTP Code: " + code);

                        Transport.send(message);
                    }catch (Exception ex){
                        ex.printStackTrace();
                    }



                    Dialog<String> dialog = new Dialog<>();
                    dialog.setTitle("Enter OTP");
                    dialog.setHeaderText("Please enter the OTP code:");

                    TextField otpTxtfield = new TextField();
                    otpTxtfield.setPromptText("6 Digit Code");

                    VBox content = new VBox(10, new Label("OTP:"), otpTxtfield);
                    content.setAlignment(Pos.CENTER);
                    dialog.getDialogPane().setContent(content);

                    ButtonType submitBtn = new ButtonType("Submit", ButtonBar.ButtonData.OK_DONE);
                    ButtonType cancelBtn = new ButtonType("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);
                    dialog.getDialogPane().getButtonTypes().addAll(submitBtn, cancelBtn);

                    dialog.setResultConverter(dialogButton -> {
                        if(dialogButton == submitBtn){
                            return otpTxtfield.getText();
                        }
                        return null;
                    });

                    dialog.showAndWait().ifPresent(otpCode -> {
                        if(code.equals(otpCode)){
                            Alert alert = new Alert(Alert.AlertType.INFORMATION);
                            alert.setTitle("Success!");
                            alert.setHeaderText("Success!");
                            alert.setContentText("OTP verification successful!");
                            alert.showAndWait();
                            isSuccess = true;

                        } else {
                            Alert alert = new Alert(Alert.AlertType.ERROR);
                            alert.setTitle("Error!");
                            alert.setHeaderText("Invalid!");
                            alert.setContentText("Invalid OTP. Please try again.");
                            alert.showAndWait();
                            return;
                        }
                    });
                    if(isSuccess){
                        Dialog<String> newPassDialog = new Dialog<>();
                        newPassDialog.setTitle("Create new password");
                        newPassDialog.setHeaderText("New Password");

                        PasswordField newPassField = new PasswordField();
                        newPassField.setPromptText("New password");

                        VBox newPassContent = new VBox(10, new Label("Enter your new Password"), newPassField);
                        newPassContent.setAlignment(Pos.CENTER);
                        newPassDialog.getDialogPane().setContent(newPassContent);

                        ButtonType submitPass = new ButtonType("Confirm", ButtonBar.ButtonData.OK_DONE);
                        ButtonType cancelPass = new ButtonType("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);
                        newPassDialog.getDialogPane().getButtonTypes().addAll(cancelPass, submitPass);

                        newPassDialog.setResultConverter(newPassDialogBtn -> {
                            if(newPassDialogBtn == submitPass){
                                return newPassField.getText();
                            }
                            return null;
                        });
                        newPassDialog.showAndWait().ifPresent(valuePass ->{
                            Database db1 = new Database();
                            Connection connectDB1 = db1.getLink();
                            try {
                                connectDB1.setAutoCommit(false);
                            } catch (SQLException e) {
                                throw new RuntimeException(e);
                            }

                            String updatePass = "update epaytable set password = ? where emailaddress = ?";
                            try {
                                PreparedStatement pstmt = connectDB1.prepareStatement(updatePass);
                                pstmt.setString(1, valuePass);
                                pstmt.setString(2, searchInput.getText());
                                pstmt.executeUpdate();
                                connectDB1.commit();

                                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                                alert.setTitle("Notice");
                                alert.setHeaderText("Success!");
                                alert.setContentText("Password updated successfully!");
                                alert.showAndWait();

                                connectDB1.setAutoCommit(true);
                                connectDB1.close();

                            } catch (SQLException e) {
                                throw new RuntimeException(e);
                            }
                        });

                    }


                //else here if email not found
                }else{
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error");
                    alert.setHeaderText("Opps");
                    alert.setContentText("Email not found!");
                    alert.showAndWait();
                    return;
                }
            }
        }else if(searchInput.getText().startsWith("+63")){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Not Available");
            alert.setContentText("Phonenumber is currently not available.");
            alert.showAndWait();
            return;


//            ResultSet rs = numberS.executeQuery(searchNumberStatement);
//            while (rs.next()){
//                if(rs.getInt(1) == 1){
//
//                }else{
//                    Alert alert = new Alert(Alert.AlertType.ERROR);
//                    alert.setTitle("Error");
//                    alert.setHeaderText("Opps");
//                    alert.setContentText("Phonenumber not found!");
//                    alert.showAndWait();
//                    return;
//                }
            //else here if incorrect input of searchInput
        }else{
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Invalid email or phonenumber!");
            alert.setContentText("Please check your email or (+63)phonenumber.");
            alert.showAndWait();
            return;
        }


    }
    public String otpGenerator(){
        Random random = new Random();
        int otp = random.nextInt(1000000);
        return String.format("%06d", otp);
    }
}
