package com.main.epayphmain;

import com.twilio.rest.chat.v1.service.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.IOException;
import java.sql.*;
import java.util.Properties;
import java.util.Random;

public class profileController {

    @FXML
    private Label statusTxt;
    @FXML
    private Label fullnameTxt;
    @FXML
    private Label ageTxt;
    @FXML
    private Label birthdayTxt;
    @FXML
    private Label genderTxt;
    @FXML
    private Label cardnumberTxt;
    @FXML
    private Label savingsnumberTxt;
    @FXML
    private Label emailTxt;
    @FXML
    private Label passTxt;
    @FXML
    private Label pinTxt;
    @FXML
    private Button passShowBtn;
    @FXML
    private Button pinShowBtn;
    @FXML
    private Button verifyBtn;
    @FXML
    private Button twoFABtn;
    @FXML
    private Label twoFA;



    private  boolean isPassVisible = false;
    private  boolean isPinVisible = false;


    @FXML
    private void initialize() throws SQLException {
        statusTxt.setText("");
        fullnameTxt.setText("");
        ageTxt.setText("");
        birthdayTxt.setText("");
        genderTxt.setText("");
        cardnumberTxt.setText("");
        savingsnumberTxt.setText("");
        emailTxt.setText("");
        passShowBtn.setText("Show");
        pinShowBtn.setText("Show");

        Database db = new Database();
        Connection con = db.getLink();
        UserSession userSession = UserSession.getInstance();
        String OTP = "select OTP from epaytable where emailaddress = ?";
        PreparedStatement pst = con.prepareStatement(OTP);
        pst.setString(1, userSession.getCurrentEmail());
        ResultSet rs = pst.executeQuery();

        if(rs.next()){
            String otp = rs.getString("OTP");
            if(otp.equals("ON")){
                twoFA.setStyle("-fx-text-fill: GREEN;");
                twoFABtn.setText("OFF");
                isON = true;
            }else{
                twoFA.setStyle("-fx-text-fill: RED;");
                twoFABtn.setText("ON");
                isON = false;
            }
        }

        loadData();

    }

    boolean isON;
    public void setTwoFABtn(ActionEvent e) throws SQLException, IOException {

        if(isON){
            boolean isConfirmed = alertBox1("Disable 2FA on your account?");
            if(isConfirmed){
                String getOtp = otpGenerator();
                UserSession userSession = UserSession.getInstance();
                emailSender es =  new emailSender();
                dialogBox dB = new dialogBox();
                es.sendEmail("Disable 2FA on your account?", "If you do not request this message please disregard this message. \n Your OTP Code: "+ getOtp, userSession.getCurrentEmail());
                boolean isTrue = dB.getAlertOTPBox(getOtp);
                if(isTrue){
                    Database db1 = new Database();
                    Connection connectDB1 = db1.getLink();
                    String usage = "update epaytable set OTP = ? where emailaddress = ?";
                    PreparedStatement ps = connectDB1.prepareStatement(usage);
                    ps.setString(1, "OFF");
                    ps.setString(2, userSession.getCurrentEmail());
                    int rowsAffected = ps.executeUpdate();
                    if(rowsAffected>0){
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setContentText("Successfully turned off 2FA on your account on your account!");
                        alert.setHeaderText(null);
                        alert.setTitle("Success!");
                        alert.showAndWait();
                    }else{
                        alertBox("Something went wrong!");
                    }
                }
                reloadScene();
                return;
            }

        }else{
            boolean isConfirmed = alertBox1("Enable 2FA on your account?");
            if(isConfirmed){
                String getOtp = otpGenerator();
                UserSession userSession = UserSession.getInstance();
                emailSender es =  new emailSender();
                dialogBox dB = new dialogBox();
                System.out.println(userSession.getCurrentEmail());
                es.sendEmail("Enable 2FA on your account?", "If you do not request this message please disregard this message. \n Your OTP Code: "+ getOtp, userSession.getCurrentEmail());
                boolean isTrue = dB.getAlertOTPBox(getOtp);
                if(isTrue){
                    Database db1 = new Database();
                    Connection connectDB1 = db1.getLink();
                    String usage = "update epaytable set OTP = ? where emailaddress = ?";
                    PreparedStatement ps = connectDB1.prepareStatement(usage);
                    ps.setString(1, "ON");
                    ps.setString(2, userSession.getCurrentEmail());
                    int rowsAffected = ps.executeUpdate();
                    if(rowsAffected>0){
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setContentText("Successfully turned on 2FA on your account on your account!");
                        alert.setHeaderText(null);
                        alert.setTitle("Success!");
                        alert.showAndWait();
                    }else{
                        alertBox("Something went wrong!");
                    }
                }
                reloadScene();
                return;
            }
        }
        isON = !isON;
    }


    public void passShowMethod(ActionEvent e){
        UserSession userSession = UserSession.getInstance();
        if (userSession.getPassword() != null){
            if(isPassVisible){
                passTxt.setText("---------------");
                passShowBtn.setText("Show");
            }else{
                passTxt.setText(userSession.getPassword());
                passTxt.setStyle("-fx-font-size: 8px");
                passShowBtn.setText("Hide");
            }
            isPassVisible = !isPassVisible;
        }
    }

    public void pinShowMethod(ActionEvent e){
        UserSession userSession = UserSession.getInstance();

        if(userSession.getPassword() != null){
            if(isPinVisible){
                pinTxt.setText("---------------");
                pinShowBtn.setText("Show");
            }else {
                pinTxt.setText(userSession.getPin());
                pinShowBtn.setText("Hide");
            }
            isPinVisible = !isPinVisible;
        }
    }


    public void profileBtn(ActionEvent e) throws IOException, SQLException {
        profile(e);
    }

    public void dashboardBtn(ActionEvent e) throws SQLException, IOException {
        Controller c = new Controller();
        c.dashboardBtn(e);
    }

    public void logOUT(ActionEvent e) throws IOException {
        Controller c = new Controller();
        c.logOUT(e);
    }

    public void profile(ActionEvent e) throws IOException, SQLException {
        FXMLLoader profileLoader = new FXMLLoader(Main.class.getResource("profileScreen.fxml"));
        Stage profileStage = (Stage)((Node) e.getSource()).getScene().getWindow();

        Scene profileScene = new Scene(profileLoader.load());
        profileStage.setScene(profileScene);
        profileStage.show();

        profileController controller = profileLoader.getController();
        controller.loadData();
    }

    public void loadData() throws SQLException {
        UserSession us = UserSession.getInstance();
        String userEmail = us.getUserEmail();
        Database db1 = new Database();
        Connection connection = db1.getLink();

        String getData = "select status, fullname, age, birthday, gender, cardnumber, savingsnumber, password, pin, savingsnumber from epaytable where emailaddress = ?";

        PreparedStatement ps = connection.prepareStatement(getData);
        ps.setString(1, userEmail);

        ResultSet rs = ps.executeQuery();
        UserSession userSession = UserSession.getInstance();

        if (rs.next()) {
            userSession.setStatus(rs.getString("status"));
            userSession.setFullname(rs.getString("fullname"));
            userSession.setAge(rs.getString("age"));
            userSession.setBirthday(rs.getString("birthday"));
            userSession.setGender(rs.getString("gender"));
            userSession.setCardnumber(rs.getString("cardnumber"));
            userSession.setSavingsnumber(rs.getString("savingsnumber"));
            userSession.setPassword(rs.getString("password"));
            userSession.setPin(rs.getString("pin"));
        }

        connection.close();
        updateUI(userSession);
    }

    private void updateUI(UserSession userSession) {
        if (userSession.getStatus() != null) {
            statusTxt.setText(userSession.getStatus());
            if (userSession.getStatus().equals("Non-Verify")) {
                statusTxt.setStyle("-fx-text-fill: RED;");
                verifyBtn.setVisible(true);
            } else if (userSession.getStatus().equals("BLOCKED")) {
                statusTxt.setStyle("-fx-text-fill: WHITE; -fx-background-color: BLACK;");
                verifyBtn.setVisible(false);
            } else {
                statusTxt.setStyle("-fx-text-fill: GREEN;");
                verifyBtn.setVisible(false);
            }
        }

        fullnameTxt.setText(userSession.getFullname());
        ageTxt.setText(userSession.getAge());
        birthdayTxt.setText(userSession.getBirthday());
        genderTxt.setText(userSession.getGender());
        cardnumberTxt.setText(userSession.getCardnumber());
        savingsnumberTxt.setText(userSession.getSavingsnumber());
        emailTxt.setText(userSession.getUserEmail());
        savingsnumberTxt.setText(userSession.getSavingsnumber());
    }

    @FXML
    private TextField cardNumberInput;
    @FXML
    private TextField validThruInput;
    @FXML
    private TextField cvcInput;

    static String strCN = "";
    static String strVT = "";
    static String strCVC = "";
    static boolean isSuccess = false;
    static String codes = "";

    public void verifyMethod(ActionEvent e) throws SQLException {

        if(cardNumberInput.getText().length() == 16){
            strCN = cardNumberInput.getText();
            if (validThruInput.getText().matches("^\\d+/\\d+$")) {
                if(validThruInput.getText().length() == 5){
                    strVT = validThruInput.getText();
                    if (cvcInput.getText().length() == 3){
                        strCVC = cvcInput.getText();

                        Database db2 = new Database();
                        Connection connectDB2 = db2.getLink();

                        String finder = "SELECT count(1) FROM epaytable WHERE cardnumber = ? AND validthru = ? AND cvc = ?";
                        PreparedStatement pt = connectDB2.prepareStatement(finder);
                        pt.setString(1, cardNumberInput.getText());
                        pt.setString(2, validThruInput.getText());
                        pt.setString(3, cvcInput.getText());

                        ResultSet findResult = pt.executeQuery();

                        if (findResult.next() && findResult.getInt(1) == 1) {
                            UserSession session = UserSession.getInstance();

                            Database connectNow1 = new Database();
                            Connection db1 = connectNow1.getLink();
                            db1.setAutoCommit(false);
                            String sql = "update epaytable set password = ?, birthday = ?, phonenumber = ?, status = ?, savingsnumber = ?, savingsbalance = ? where cardnumber = '" + strCN + "' ";
                            try {
                                PreparedStatement pstmt = db1.prepareStatement(sql);
                                pstmt.setString(1, session.getPasD());
                                pstmt.setString(2, session.getBY());
                                pstmt.setString(3, session.getEmL());
                                pstmt.setString(4, "VERIFIED");
                                pstmt.setString(5, savingsNumber());
                                pstmt.setString(6, "0.0");


                                if (session.isBol()) {
                                    codes = otpGenerator();

                                    String host = "smtp.gmail.com";
                                    final String username = "www.epay.ph@gmail.com";
                                    final String password3 = "yock jasy ojrb esbp";

                                    Properties props = new Properties();
                                    props.put("mail.smtp.auth", "true");
                                    props.put("mail.smtp.starttls.enable", "true");
                                    props.put("mail.smtp.host", host);
                                    props.put("mail.smtp.port", "587");

                                    Session session1 = Session.getInstance(props, new Authenticator() {
                                        @Override
                                        protected PasswordAuthentication getPasswordAuthentication() {
                                            return new PasswordAuthentication(username, password3);
                                        }
                                    });

                                    try {
                                        Message message = new MimeMessage(session1);
                                        message.setFrom(new InternetAddress("www.epay.ph@gmail.com"));
                                        message.setRecipient(Message.RecipientType.TO, new InternetAddress(session.getEmL()));
                                        message.setSubject("Card Number Account Link | Epay.PH Official");
                                        message.setText("Your OTP Code: " + codes);

                                        Transport.send(message);
                                    } catch (Exception ex) {
                                        ex.printStackTrace();
                                    }
//                Message message = prepareMessage(session, strEmail, code);
//                assert message != null;

                                } else {
                                    Alert alert = new Alert(Alert.AlertType.ERROR);
                                    alert.setTitle("Notice!");
                                    alert.setContentText("Phone number is under development!");
                                    alert.showAndWait();
                                    //withfalse noon
                                    return;
//                phoneNumberSender pns = new phoneNumberSender();
//                pns.PhoneNumber(Acc_SID, Acc_Token, strPhoneNumber,mesOTP);
                                    //PhoneNumber(Acc_SID, Acc_Token, strPhoneNumber,mesOTP);
//                PhonenumberOTP(strPhoneNumber, mesOTP);
                                }

                                Dialog<String> dialog = new Dialog<>();
                                dialog.setTitle("Enter OTP");
                                dialog.setHeaderText("Please enter the OTP code:");

                                TextField otpTxtfield = new TextField();
                                otpTxtfield.setPromptText("6 Digit Code");

                                VBox content = new VBox(10, new Label("OTP:"), otpTxtfield);
                                content.setAlignment(Pos.CENTER);
                                dialog.getDialogPane().setContent(content);

                                ButtonType submitBtn = new ButtonType("Submit", ButtonBar.ButtonData.OK_DONE);
                                ButtonType cancelBtn = new ButtonType("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);
                                dialog.getDialogPane().getButtonTypes().addAll(submitBtn, cancelBtn);

                                dialog.setResultConverter(dialogButton -> {
                                    if (dialogButton == submitBtn) {
                                        return otpTxtfield.getText();
                                    }
                                    return null;
                                });

                                dialog.showAndWait().ifPresent(otpCode -> {
                                    if (codes.equals(otpCode)) {
                                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                                        alert.setTitle("Success!");
                                        alert.setHeaderText("Success!");
                                        alert.setContentText("OTP verification successful!");
                                        alert.showAndWait();
                                        isSuccess = true;

                                    } else {
                                        Alert alert = new Alert(Alert.AlertType.ERROR);
                                        alert.setTitle("Error!");
                                        alert.setHeaderText("Invalid!");
                                        alert.setContentText("Invalid OTP. Please try again.");
                                        alert.showAndWait();
                                        isSuccess = false;
                                    }
                                });

                                if (isSuccess) {
                                    int update = pstmt.executeUpdate();
                                    db1.commit();
                                    db1.setAutoCommit(true);
                                    db1.close();
                                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                                    alert.setTitle("Notice!");
                                    alert.setHeaderText("Success!");
                                    alert.setContentText("Account Created!" + "\nTrace number: "+update);
                                    alert.showAndWait();
                                    Main mainApp = Main.getInstance();
                                    mainApp.switchScene("loginScreen.fxml");
                                    emailSender es = new emailSender();
                                    es.sendEmail("You have successfully linked your account online!", "Hi Sir/Maam, Good day! \n Your account is marked as VERIFIED, this means you can send money and use other features of Epay.PH! \n\nThank you!", session.getEmL());

                                }
                            } catch (SQLIntegrityConstraintViolationException ex) {
                                ex.printStackTrace();
                            } catch (Exception ex) {
                                ex.printStackTrace();
                            }





                        }else{
                            alertBox("Card not found!");
                        }



                    }else{
                        alertBox("Please enter the correct CVC!");
                    }
                }else{
                    alertBox("Please enter a valid date!");
                }

            }else{
                alertBox("Please enter the correct format!");
            }

        } else {
            alertBox("Please input your 16 digit Card Number!");
        }
    }
    public void cancelBtnLink(ActionEvent e) throws IOException {
        Main mainApp = Main.getInstance();
        mainApp.switchScene("profileScreen.fxml");
    }

    public String savingsNumber(){
        Random random = new Random();
        long num = Math.abs(random.nextLong() % 10000000000000L) + 1000000000000L;
        return String.format("%013d", num);
    }


    public boolean alertBox1(String content){
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Notice!");
        alert.setHeaderText(null);
        alert.setContentText(content);

        ButtonType buttonTypeConfirm = new ButtonType("Yes");
        ButtonType buttonTypeCancel = new ButtonType("No");

        alert.getButtonTypes().setAll(buttonTypeConfirm, buttonTypeCancel);

        final boolean[] result = {false}; // Mutable container to hold the result

        alert.showAndWait().ifPresent(response -> {
            if (response == buttonTypeConfirm) {
                System.out.println("User confirmed the action.");
                result[0] = true;
            } else if (response == buttonTypeCancel) {
                System.out.println("User cancelled the action.");
                result[0] = false;
            }
        });

        return result[0];
    }


    public void alertBox(String content){
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    public String otpGenerator(){
        Random random = new Random();
        int otp = random.nextInt(1000000);
        return String.format("%06d", otp);
    }
    public void reloadScene() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("profileScreen.fxml"));
        Parent root = loader.load();
        Stage stage = (Stage) statusTxt.getScene().getWindow(); // Use any node to get the scene and window
        stage.setScene(new Scene(root));
        stage.show();
    }
    public void gotoAccountTab(ActionEvent e) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("accountTab.fxml"));
        Parent root = loader.load();
        Scene scene = new Scene(root);
        Stage stage = (Stage) statusTxt.getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    public void changeBtn(ActionEvent e) throws SQLException {
        //ask the pass
        Dialog<String> dialog = new Dialog<>();
        dialog.setTitle("Enter new password");
        dialog.setHeaderText(null);

        PasswordField pass = new PasswordField();
        pass.setPromptText("New Password");

        TextField retype = new TextField();
        retype.setPromptText("Re-type Password");

        VBox content = new VBox(10, pass, retype);
        content.setAlignment(Pos.CENTER);
        dialog.getDialogPane().setContent(content);

        ButtonType submitBtn = new ButtonType("Submit", ButtonBar.ButtonData.OK_DONE);
        ButtonType cancelBtn = new ButtonType("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);
        dialog.getDialogPane().getButtonTypes().addAll(submitBtn, cancelBtn);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == submitBtn) {
                return retype.getText();
            }
            return null;
        });


        dialog.showAndWait().ifPresent(repass -> {
            if (pass.getText().equals(repass)) {
                dialogBox dBox = new dialogBox();

                if(pass.getText().length() != 8 && repass.length() != 8){
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error!");
                    alert.setHeaderText(null);
                    alert.setContentText("Password must be 8 characters long!");
                    alert.showAndWait();
                    return;
                }

                boolean isOTPCorrect = dBox.getAlertOTPBox(otpGenerator());
                if(isOTPCorrect){
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Success!");
                    alert.setHeaderText("Password changed!");
                    alert.setContentText("Successfully changed password!");

                    try {
                    Database db = new Database();
                    UserSession userSession = UserSession.getInstance();
                    Connection connection = db.getLink();
                    connection.setAutoCommit(false);
                    String update = "update epaytable set password = ? where emailaddress = ?";
                    PreparedStatement preparedStatement = null;

                        preparedStatement = connection.prepareStatement(update);
                        preparedStatement.setString(1, repass);
                        preparedStatement.setString(2, userSession.getCurrentEmail());
                        preparedStatement.executeQuery();
                        connection.commit();
                        connection.setAutoCommit(true);
                        profile(e);
                    } catch (SQLException ex) {
                        throw new RuntimeException(ex);
                    } catch (IOException ex) {
                        throw new RuntimeException(ex);
                    }


                    alert.showAndWait();
                    return;
                }else{
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error!");
                    alert.setHeaderText("Invalid!");
                    alert.setContentText("Invalid OTP. Please try again.");
                    alert.showAndWait();
                    return;
                }

            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error!");
                alert.setHeaderText("Invalid!");
                alert.setContentText("Incorrect!");
                alert.showAndWait();
                return;
            }
        });
    }

}
