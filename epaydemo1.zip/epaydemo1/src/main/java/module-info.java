module com.main.epaydemo1 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires java.mail;
    requires twilio;
    requires mysql.connector.j;
    requires fonts.fontawesome;
    requires fontawesomefx;
    requires controlsfx;
    requires javafx.graphics;


    opens com.main.epayphmain to javafx.fxml;
    exports com.main.epayphmain;
}