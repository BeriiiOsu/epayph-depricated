import os
import datetime
import time
import getpass         #for hiding pin when input

#local imports required!
from database import data


def screen():
    atm_art = """
     _____    ____      _    __   __  
    | ____|  |  _ \\    / \\   \\ \\ / / 
    |  _|    | |_) |  / _ \\   \\ V / 
    | |___   |  __/  / ___ \\   | |   
    |_____|  |_|    /_/   \\_\\  |_|   
    _________________________________________________
    """

    print(atm_art)

def screen2():
    atm_art = """
     _____    ____      _    __   __  
    | ____|  |  _ \\    / \\   \\ \\ / / 
    |  _|    | |_) |  / _ \\   \\ V / 
    | |___   |  __/  / ___ \\   | |   
    |_____|  |_|    /_/   \\_\\  |_|   
    _________________________________________________
    | |
    | |     [1] Deposit
    | |     [2] Withdraw
    | |     [3] Balance Inquiry
    | |     [4] Exit
    | |
    """

    print(atm_art)
    
def depositScreen():
        deposit = """
     _____    ____      _    __   __  
    | ____|  |  _ \\    / \\   \\ \\ / / 
    |  _|    | |_) |  / _ \\   \\ V / 
    | |___   |  __/  / ___ \\   | |   
    |_____|  |_|    /_/   \\_\\  |_|   DEPOSIT
    _________________________________________________
    """
        print(deposit)
def withdrawScreen():
    withdraw = """
     _____    ____      _    __   __  
    | ____|  |  _ \\    / \\   \\ \\ / / 
    |  _|    | |_) |  / _ \\   \\ V / 
    | |___   |  __/  / ___ \\   | |   
    |_____|  |_|    /_/   \\_\\  |_|   WITHDRAW
    _________________________________________________
    """
    print(withdraw)

def checkBalanceScreen():
    checkBalance = """
     _____    ____      _    __   __  
    | ____|  |  _ \\    / \\   \\ \\ / / 
    |  _|    | |_) |  / _ \\   \\ V / 
    | |___   |  __/  / ___ \\   | |   
    |_____|  |_|    /_/   \\_\\  |_|   CHECK BALANCE
    _________________________________________________
    """
    print(checkBalance)

def clear():
    if os.name == 'nt':
        os.system('cls')
    else:
        os.system('clear')



class loginScreen:
    def __init__(self):
        try:
            db = data()
            sqlCursor = db.cursor()
            sqlCursor2 = db.cursor()
            sqlCursor3 = db.cursor()
            sqlCursor4 = db.cursor()

            while True:
                screen()
                userAccInput = input("Account Number: ")
                if not userAccInput.isdigit():
                    clear()
                    screen()
                    print("Invalid!")
                    print("Account number must be digits/numbers!")
                elif len(userAccInput) != 16:
                    clear()
                    screen()
                    print("Invalid!")
                    print("Account number must be 16 digits!")
                elif userAccInput.isspace():
                    clear()
                    screen()
                    print("Invalid!")
                    print("Spaces detected!")
                else:
                    clear()
                    break

            accChecker = "select status, cardnumber, validthru from epaytable where cardnumber = %s"
            sqlCursor.execute(accChecker,(userAccInput,))
            accFinder = sqlCursor.fetchone()
            status, cardnumber, validthru, = accFinder
            
            
            


            if not accFinder:
                clear()
                screen()
                print("Account not found!")
                exit()
            elif status == "BLOCKED":
                clear()
                screen()
                print("Your account is on hold!")
                print("Please contact the administrator!")
                exit()
            else:
                clear()
                currentYear = datetime.datetime.now().date()
                formattedcurrentYear = currentYear.strftime("%m/%y")
                screen()
                print("Checking Account Details...")
                time.sleep(2)
                print("Present time \t\t: " + formattedcurrentYear)
                time.sleep(2)
                print("Card's Valid Thru\t: " + validthru)
                if str(formattedcurrentYear) == str(validthru):
                    clear()
                    screen()
                    print("Card expired!")
                    print("Please Update the card.")
                    exit()
                
                time.sleep(2)


                clear()
                accCheckPin = "select pin from epaytable where cardnumber = %s"
                sqlCursor.execute(accCheckPin,(cardnumber,))
                pinFinder = sqlCursor.fetchone()

                if pinFinder:
                    sqlPin = pinFinder[0]  
                else:
                    clear()
                    screen()
                    print("PIN not found!")
                    exit()

                attempts = 0
                while attempts < 3:
                    screen()
                    pin = getpass.getpass("PIN (4 digits): ")
                    
                    if not pin.isdigit():
                        clear()
                        screen()
                        print("PIN must be digit/number!")
                        input()
                        clear()
                    elif len(pin) != 4:
                        clear()
                        screen()
                        print("PIN must be 4 digits!")
                        input()
                        clear()
                    elif pin.isspace():
                        clear()
                        screen()
                        print("Spaces detected!")
                        input()
                        clear()
                    else:
                        if attempts >=3:
                            clear()
                            print("Account BLOCKED!")
                            statusUpdater = "update epaytable set status = %s where cardnumber = %s"
                            prompt = ("BLOCKED", cardnumber)
                            sqlCursor.execute(statusUpdater, prompt)
                            db.commit()
                            exit()
                        # pin = int(pin)
                        if sqlPin != pin:
                            attempts += 1
                            clear()
                            screen()
                            print("Incorrect PIN! Attempts remaining:", 3 - attempts)
                        else:
                            info = "select status, pin, cardnumber, cvc, validthru, cardNetwork, cardType, fullname, age, gender, emailaddress, balance, lastupdated, datecreated from epaytable where cardnumber = %s"
                            sqlCursor.execute(info, (cardnumber,))
                            userData = sqlCursor.fetchone()
                            status1, pin1, cardnumber1, cvc1, validthru1, cardnetwork1, cardtype1, fullname1, age1, gender1, emailadd1, balance1, lastupdated1, datecreated1  = userData
                            while True:
                                clear()
                                screen2()
                                print("--->     Welcome " + fullname1 + "!"+ "     <---")
                                userInput3 = input("--->     Select an option: ")
                                clear()
                                
                                #Deposit
                                if userInput3 == "1":
                                    while True:
                                        depositScreen()
                                        floatBalance = float(balance1)
                                        print("--->     Max Balance is 500,000")
                                        print("Type [B] for back.")
                                        depositAmount = input("--->     Enter amount: ")

                                        if depositAmount == "B":
                                            clear()
                                            break

                                        if depositAmount.isdigit() or depositAmount.isdecimal():
                                            testBal = floatBalance + float(depositAmount)
                                            depositAmount = float(depositAmount)
                                            if depositAmount <= 100:
                                                clear()
                                                print("Amount should be greater than or equal to 100!")
                                                input()
                                                clear()
                                            elif depositAmount > 500000:
                                                clear()
                                                print("Maximum deposit is 500,000")
                                                input()
                                                clear()
                                            elif testBal > 500000:
                                                clear()
                                                print("Process cant be done!")
                                                print("Balance is over 500,000!")
                                                input()
                                                clear()
                                            else:
                                                clear()
                                                screen()
                                                print("Please wait...")
                                                lastUpdater = datetime.datetime.now()
                                                time.sleep(5)
                                                Bal = floatBalance + float(depositAmount)
                                                newBal = f"{Bal: .2f}"
                                                balanceChanger = "update epaytable set balance = %s where cardnumber = %s"
                                                dateChanger = "update epaytable set lastupdated = %s where cardnumber = %s"
                                                prompt2 = (newBal, cardnumber)
                                                prompt3 = (lastUpdater, cardnumber)
                                                sqlCursor2.execute(balanceChanger, prompt2)
                                                sqlCursor2.execute(dateChanger, prompt3)
                                                db.commit()
                                                print("Successfully deposited!")
                                                input()
                                                
                                                clear()
                                                break
                                        else:
                                            print("Invalid Input!")
                                            input()
                                            clear()
                                    
                                    
                                #Withdraw
                                elif userInput3 == "2":
                                    loop = True
                                    withdrawScreen()
                                    floatBalance = float(balance1)
                                    if floatBalance <= 100:
                                        clear()
                                        print("Insufficient funds!")
                                        print("Please deposit atleast 100.")
                                        input()
                                        loop = False
                                        clear()
                                    while loop:
                                        print("Type [B] for back.")
                                        withdrawAmount = (input("--->     Enter amount: "))
                                        if withdrawAmount == "B":
                                            clear()
                                            break
                                        if withdrawAmount.isdigit() or withdrawAmount.isdecimal():
                                            withdrawAmount = float(withdrawAmount)
                                            if withdrawAmount > floatBalance:
                                                clear()
                                                print("The amount should not be higher than your balance!")
                                                input()
                                                clear()
                                            elif withdrawAmount < 100:
                                                clear()
                                                print("Amount should not be negative or less than 100.")
                                                input()
                                                clear()
                                            else:
                                                clear()
                                                screen()
                                                print("Please wait...")
                                                lastUpdater = datetime.datetime.now()
                                                time.sleep(5)
                                                bal = floatBalance - withdrawAmount
                                                newBal = f"{bal: .2f}"
                                                balanceChanger = "update epaytable set balance = %s where cardnumber = %s"
                                                dateChanger = "update epaytable set lastupdated = %s where cardnumber = %s"
                                                prompt4 = (newBal, cardnumber)
                                                prompt5 = (lastUpdater, cardnumber)
                                                sqlCursor3.execute(balanceChanger, prompt4)
                                                sqlCursor3.execute(dateChanger, prompt5)
                                                db.commit()
                                                print("Successfully Withdrawed!")
                                                input()
                                                
                                                clear()
                                                break
                                            
                                        else:
                                            print("Invalid Input!")

                                #checkBalance
                                elif userInput3 == "3":
                                    checkBalanceScreen()
                                    balInfo = "select balance, lastupdated from epaytable where cardnumber = %s"
                                    sqlCursor4.execute(balInfo, (cardnumber,))
                                    balData, lastupdated2, = sqlCursor4.fetchone()
                                    print("--->     Current Balance:" , balData)
                                    print("--->     Last Updated: " + lastupdated2)
                                    input()
                                    
                                    clear()
                                elif userInput3 == "4":
                                    clear()
                                    screen()
                                    print("Thank you for using EPAY!")
                                    exit()
                                else:
                                    clear()
                                    print("Invalid Input!")
                                    input()
                                    clear()
                    
        except Exception as err:
            print("Error: ", err)