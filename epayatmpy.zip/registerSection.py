import mysql.connector
import random          #for random number
import datetime
import os
from dateutil.relativedelta import relativedelta
from mysql.connector import Error

#local imports (required!)
from database import data

def clear():
    if os.name == 'nt':
        os.system('cls')
    else:
        os.system('clear')

class registerScreen():
    def __init__(self):
        cardNetwork = ""
        cardType = ""
        try:
            db = data()
            mysqlCursor = db.cursor()
            print("Choose Card Network: ")
            while True:
                print("1. Mastercard")
                print("2. Visa")
                userInput2 = int(input("> "))
                if userInput2 == 1:
                    cardNetwork = "Mastercard"
                    accNum = mastercard(mysqlCursor)
                    break
                elif userInput2 == 2:
                    cardNetwork = "Visa"
                    accNum = visa(mysqlCursor)
                    break
                else:
                    print("Invalid Input!")
            clear()

            print("Choose Card Type: ")
            while True:
                print("1. Credit card")
                print("2. Debit card")
                print("3. Prepaid card")
                print("4. Commercial Card")
                userInput2 = int(input("> "))
                if userInput2 == 1:
                    cardType = "Credit"
                    break
                elif userInput2 == 2:
                    cardType = "Debit"
                    break
                elif userInput2 == 3:
                    cardType = "Prepaid"
                    break
                elif userInput2 == 4:
                    cardType = "Commercial"
                    break
                else:
                    print("Invalid Input!")
            
            clear()

            print("<= = = REGISTRATION = = =>")
            fullname = input("Fullname(First,Middle,Last): ")

            age = input("Age: ")
            age = int(age)
            if age < 18:
                print("You are underage!")
                exit()
            elif age >= 100:
                print("You are overage!")
                exit()
            age = str(age)


            while True:
                gender = input("Gender([M]ale,[F]emale,[O]thers): ").upper()
                if gender not in ["M", "F", "O"]:
                    print("Invalid Gender! Please enter M, F, or O.")
                else:
                    break
                
            email = input("Email Address (Type N/A if not have): ")
            datecreated = str(datetime.date.today())
            lastupdated = str(datetime.date.today())

            current_date = datetime.datetime.now().date()

            addyears = current_date + relativedelta(years=5)

            validthru = addyears.strftime("%m/%y")

            cvc = random.randint(100, 999)

            while True:
                try:
                    pin = input("PIN (4 digits only!): ")
                    if len(pin) != 4 or not pin.isdigit():
                        print("Please enter a 4-digit PIN!")
                    else:
                        confirm = input("Re-type your 4-digit PIN: ")
                        if pin == confirm:
                            clear()
                            print("PIN set successfully!")
                            break
                        else:
                            print("PIN does not match!")
                except ValueError:
                    print("Invalid input! Please enter digits only.")
            
            checker(pin, accNum, cvc, validthru, cardNetwork, cardType, fullname, age, gender, email, datecreated, lastupdated)
            print("Data not saved!")
            exit()
            

        except mysql.connector.Error as err:
            print("Error:", err)

    
                    
def checker(pin, accNum, cvc, validthru, cardNetwork, cardType, fullname, age, gender, email, datecreated, lastupdated):
    cvc = str(cvc)
    print("===== Check your Details =====")
    print("Account \t: " + accNum)
    print("Card Networdk \t: " + cardNetwork)
    print("Card Type \t: " + cardType)
    print("CVC \t\t: " + cvc)
    print("Valid Thru \t: "+ validthru)
    print("PIN \t\t: " + pin)
    print("Fullname \t: " + fullname)
    print("Age \t\t: " + age)
    print("Gender \t\t: " + gender)
    print("EmailAdd \t: " + email)
    print()
    print("Is your details correct?")
    print("[Y]es")
    print("[N]o (It will reset!)")
    while True:
        userInput = input("> ").upper()
        if userInput not in ["Y","N"]:
            print("Invalid Input!")
        elif userInput == "Y":
            userData(pin, accNum, cvc, validthru, cardNetwork, cardType, fullname, age, gender, email, datecreated, lastupdated)
        elif userInput == "N":
            return


def userData(pin, accNum, cvc, validthru, cardNetwork, cardType, fullname, age, gender, email, datecreated, lastupdated):
    try:
        status = "Non-Verify" #Healthy/Warning/BLOCKED
        balance = 0.0
        OTP = "OFF"
        command = "INSERT INTO epaytable (status, OTP, pin, cardnumber, cvc, validthru, cardNetwork, cardType, fullname, age, gender, emailaddress, balance, lastupdated, datecreated) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
        vaLues = (status, OTP, pin, accNum, cvc, validthru, cardNetwork, cardType, fullname, age, gender, email, balance, lastupdated, datecreated)
        db = data()
        mysqlCursor = db.cursor()
        mysqlCursor.execute(command, vaLues)
        db.commit()
    except Error as e:
        print("Email address is already used.")
        db.rollback()
        exit()

    clear()
    print("You have successfully registered!")
    print("Current Balance: 0")
    print("Status: " + status)
    exit()

def mastercard(cursor):
    while True:
        accNo1 = random.randint(51, 55)
        accno15 = random.randint(10,99)
        accNo2 = random.randint(1000, 9999)
        accNo3 = random.randint(1000, 9999)
        accNo4 = random.randint(1000, 9999) 

        mainAccNo = str(accNo1)+str(accno15)+str(accNo2)+str(accNo3)+str(accNo4)
        cursor.execute("select status, pin, cardnumber, cvc, validthru, cardNetwork, cardType, fullname, age, gender, emailaddress, balance, lastupdated, datecreated from epaytable where cardnumber = %s", (mainAccNo,))
        if cursor.fetchone() is None:
            return mainAccNo
        else:
            print("An error occured...")
            print("Restarting...")

def visa(cursor):
    while True:
        accNo1 = random.randint(100, 999)
        accNo2 = random.randint(1000, 9999)
        accNo3 = random.randint(1000, 9999)
        accNo4 = random.randint(1000, 9999) 

        mainAccNo = "4"+str(accNo1)+str(accNo2)+str(accNo3)+str(accNo4)
        cursor.execute("select status, pin, cardnumber, cvc, validthru, cardNetwork, cardType, fullname, age, gender, emailaddress, balance, lastupdated, datecreated from epaytable where cardnumber = %s", (mainAccNo,))
        if cursor.fetchone() is None:
            return mainAccNo
        else:
            print("An error occured...")
            print("Restarting...")

            