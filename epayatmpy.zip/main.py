import os              #for clearing console
#local imports(required)
from loginSection import loginScreen
from registerSection import registerScreen

mainscreen = """
 __        __   _                              _ 
 \\ \\      / /__| | ___ ___  _ __ ___   ___    | |
  \\ \\ /\\ / / _ \\ |/ __/ _ \\| '_ ` _ \\ / _ \\   | |
   \\ V  V /  __/ | (_| (_) | | | | | |  __/   |_|
    \\_/\\_/ \\___|_|\\___\\___/|_| |_| |_|\\___|   (_)
                                                              

    [L]ogin
    [R]egister
    [E]xit                                                        
"""


def clear():
    if os.name == 'nt':
        os.system('cls')
    else:
        os.system('clear')

clear()

while True:
    print(mainscreen)
    choice = input(": ").upper()

    if(choice == "L"):
        clear()
        loginScreen()
        print("Thank you! Comeback again!")
        exit()
    elif(choice == "R"):
        clear()
        registerScreen()
        print("Thank you! Comeback again!")
        exit()
    elif(choice == "E"):
        clear()
        print("Thank you! Comeback again!")
        exit()
    else:
        clear()
        print("Err...")
        print()




